package com.example.tictactoeapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class AlertActivity extends AppCompatActivity {



}